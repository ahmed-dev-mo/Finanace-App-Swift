//
//  SavingsViewController.swift
//  MoblieAppCW1
//
//  Created by Ahmed Mohamed on 10/03/2022.
//

import UIKit
import Foundation

class SavingsViewController: UIViewController,UITextFieldDelegate {

    func showAlert(message: String, title: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBOutlet weak var InitialAmountTF: UITextField!
    @IBOutlet weak var InterestRateTF: UITextField!
    @IBOutlet weak var ProjectedValueTF: UITextField!
    @IBOutlet weak var NumberOfPayTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func validateTexFields() -> Int {
        var counter = 0
        if !(InitialAmountTF.text?.isEmpty)! {
            counter += 1
        }
        if !(InterestRateTF.text?.isEmpty)! {
            counter += 1
        }
        if !(ProjectedValueTF.text?.isEmpty)! {
            counter += 1
        }
        if !(NumberOfPayTF.text?.isEmpty)! {
            counter += 1
        }
        
        return counter
    }
    
    func resetTextFields() {
        InitialAmountTF.text = ""
        InterestRateTF.text = ""
        ProjectedValueTF.text = ""
        NumberOfPayTF.text = ""
    }
    

    func findMissingInitalAmount(interest: Double , futureValue: Double, noOfYears: Double) -> Double {

        let A = Double(futureValue)
         let R = Double(interest) / 100
        let T = Double(noOfYears)
        let P = Double(A / pow(1 + (R / 12), 12*T))

        return P.toFixed(2)

    }
    
        
    func findMissingInterestRate(InitalValue: Double, futureValue: Double, noOfYears: Double) -> Double {
    
            let P = Double(InitalValue)
            let A = Double(futureValue)
            let T = Double(noOfYears)
            let R = Double(12*(pow((A/P),1/12*T)-1))
    
            return R.toFixed(2)
    
        }
    
    func findMissingFutureValue(InitalValue: Double, interest: Double, noOfYears: Double) -> Double {

        let P = Double(InitalValue)
        let R = Double(interest) / 100
        let T = Double(noOfYears)
        let A = Double(P * pow(1 + (R / 12), 12*T))

       return A.toFixed(2)

    }


    func findMissingNumberOfPay(InitalValue: Double, futureValue: Double, interest: Double) -> Double {

        let P = Double(InitalValue)
        let A = Double(futureValue)
        let R = Double(interest) / 100
        let T = Double(log(A/P)/12*log(1+R/12))

        return T.toFixed(2)

    }
    
    
    func calculateMissingComponent() {
        ///
        /// A           -    the future value of the investment/loan, including interest
        /// P           -    the principal investment amount (the initial deposit or loan amount – present value)
        /// R           -    the annual interest rate (e.g. 3.2% is 0.032)
        /// N           -    the number of times that interest is compounded per unit time (this is always monthly for the purpose of this coursework, i.e. 12 per year)
        /// T           -     the time the money is invested or borrowed in months
        /// PMT      -    the monthly Payment
        /// PayPY   -    the number of payments per year
        /// CpY       -    the number of compound payments per year
        /// PmtAt    -    the payment due at the beginning or end of each period (default is END)
        ///
        let P = Double(InitialAmountTF.text!)
        let R = Double(InterestRateTF.text!)
        let A = Double(ProjectedValueTF.text!)
        let T = Double(NumberOfPayTF.text!)
        
        
        
        /// Identify missing component and Perform relavant calculation
//        let A = Double(futureValue)
//        let R = Double(interest) / 100
//        let N = Double(perYear)
//        let T = Double(noOfYears)
        
        var missingValue = 0.0
        if (InitialAmountTF.text?.isEmpty)! {
            missingValue = findMissingInitalAmount(interest: R!,  futureValue: A! , noOfYears: T!)
            InitialAmountTF.text = String(missingValue)
        }
        if (InterestRateTF.text?.isEmpty)! {
            missingValue = findMissingInterestRate(InitalValue: P!, futureValue: A!, noOfYears: T!)
            InterestRateTF.text = String(missingValue)
        }
        if (ProjectedValueTF.text?.isEmpty)! {
            missingValue = findMissingFutureValue(InitalValue: P!, interest: R!, noOfYears: T!)
            ProjectedValueTF.text = String(missingValue)
        }
        if (NumberOfPayTF.text?.isEmpty)! {
            missingValue = findMissingNumberOfPay(InitalValue: P!, futureValue: A!, interest: R!)
            NumberOfPayTF.text = String(missingValue)
        }
     
        
       
    
    
    }
    @IBAction func InitialAmountChange(_ sender: UITextField) {
        if validateTexFields() == 3 {
            /// calculate Missing Component
            calculateMissingComponent()
            
            
        } else if validateTexFields() == 5 {
            showAlert(message: "Invalid Calculation. You must leave one field to proceed with a calculation", title: "Loan Calculation Warning")
        } else {
            showAlert(message: "Please fill at least three fields to perform a calculation", title: "Loan Calculation Warning")
        }
        
    }
    @IBAction func InterestChange(_ sender: UITextField) {
        if validateTexFields() == 3 {
            /// calculate Missing Component
            calculateMissingComponent()
            
            
        } else if validateTexFields() == 5 {
            showAlert(message: "Invalid Calculation. You must leave one field to proceed with a calculation", title: "Loan Calculation Warning")
        } else {
            showAlert(message: "Please fill at least three fields to perform a calculation", title: "Loan Calculation Warning")
        }
    }
    @IBAction func FutureValueChange(_ sender: UITextField) {
        if validateTexFields() == 3 {
            /// calculate Missing Component
            calculateMissingComponent()
            
            
        } else if validateTexFields() == 5 {
            showAlert(message: "Invalid Calculation. You must leave one field to proceed with a calculation", title: "Loan Calculation Warning")
        } else {
            showAlert(message: "Please fill at least three fields to perform a calculation", title: "Loan Calculation Warning")
        }
    }
    
    @IBAction func NumberofPaymentsChange(_ sender: UITextField) {
        if validateTexFields() == 3 {
            /// calculate Missing Component
            calculateMissingComponent()
            
            
        } else if validateTexFields() == 5 {
            showAlert(message: "Invalid Calculation. You must leave one field to proceed with a calculation", title: "Loan Calculation Warning")
        } else {
            showAlert(message: "Please fill at least three fields to perform a calculation", title: "Loan Calculation Warning")
        }
    }
}

//
//  CompoundInterestViewController.swift
//  MoblieAppCW1
//
//  Created by Ahmed Mohamed on 10/03/2022.
//

import UIKit
import Foundation

class CompoundInterestViewController: UIViewController,UITextFieldDelegate  {
    
    func showAlert(message: String, title: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }

    @IBOutlet weak var Initialamount_TF: UITextField!
    
    @IBOutlet weak var Interestrate_TF: UITextField!
    
    @IBOutlet weak var MonthlyPayments_TF: UITextField!
    
    @IBOutlet weak var ProjectedValue_TF: UITextField!
    
    @IBOutlet weak var NumberOfPayMents_TF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func validateTextFields() -> Int {
        var counter = 0
        if !(Initialamount_TF.text?.isEmpty)! {
            counter += 1
        }
        if !(Interestrate_TF.text?.isEmpty)! {
            counter += 1
        }
        if !(MonthlyPayments_TF.text?.isEmpty)! {
            counter += 1
        }
        if !(ProjectedValue_TF.text?.isEmpty)! {
            counter += 1
        }
        if !(NumberOfPayMents_TF.text?.isEmpty)!{
            counter += 1
        }
        
        return counter
    }
    
    func resetTextFields() {
        Initialamount_TF.text = ""
        Interestrate_TF.text = ""
        MonthlyPayments_TF.text = ""
        ProjectedValue_TF.text = ""
        NumberOfPayMents_TF.text = ""
    }
    
    
    func findMissingInitalAmount(interest: Double , futureValue: Double, noOfYears: Double) -> Double {

        let A = Double(futureValue)
         let R = Double(interest) / 100
        let PMT = Double(noOfYears)
        let P = Double(A / pow(1 + (R / 12), 12*PMT))

        return P.toFixed(2)

    }
    
    func findMissingInterestRate(InitalValue: Double, futureValue: Double, noOfYears: Double) -> Double {
    
            let P = Double(InitalValue)
            let A = Double(futureValue)
            let T = Double(noOfYears)
            let R = Double(12*(pow((A/P),1/12*T)-1))
    
            return R.toFixed(2)
    
        }
    
    func findMissingMonthly_payments(FutureValue: Double, interest: Double, noOfYears: Double) -> Double {
        
        let A = Double(FutureValue)
        let R = Double(interest)
        let T = Double(noOfYears)
        
        let PMT = Double(A/((pow(1 + (R / 12), 12*T)-1)/R/12))

        return PMT.toFixed(2)

    }
    
    func findMissingFuture_value(InitalValue: Double, interest: Double, noOfYears: Double) -> Double {
        
        
        let R = Double(interest)
        let T = Double(noOfYears)
        let P = Double(InitalValue)
        
        let PMT = Double ((P * pow(1 + (R / 12), 12*T)) +  (((pow(1 + (R / 12), 12*T)-1)/R/12)))
        
        let A = Double(PMT*(((pow(1 + (R / 12), 12*T)-1)/R/12)))

        return A.toFixed(2)

    }
    
    func findMissingNumberOfPayMents(FutureValue: Double,interest: Double,InitalValue:Double) -> Double {
        
        let R = Double(interest)
        let A = Double(FutureValue)
        let P = Double(InitalValue)
        
        let N = Double(log(A/P)/12*log(1+R/12))
        

        return N.toFixed(2)

    }
    
    func calculateMissingComponent() {
        ///
        /// A           -    the future value of the investment/loan, including interest
        /// P           -    the principal investment amount (the initial deposit or loan amount – present value)
        /// R           -    the annual interest rate (e.g. 3.2% is 0.032)
        /// N           -    the number of times that interest is compounded per unit time (this is always monthly for the purpose of this coursework, i.e. 12 per year)
        /// T           -     the time the money is invested or borrowed in months
        /// PMT      -    the monthly Payment
        /// PayPY   -    the number of payments per year
        /// CpY       -    the number of compound payments per year
        /// PmtAt    -    the payment due at the beginning or end of each period (default is END)
        ///
        let P = Double(Initialamount_TF.text!)
        let R = Double(Interestrate_TF.text!)
        let T = Double(MonthlyPayments_TF.text!)
        let A = Double(ProjectedValue_TF.text!)
        _ = Double(NumberOfPayMents_TF.text!)
        
        
        
        /// Identify missing component and Perform relavant calculation
//        let A = Double(futureValue)
//        let R = Double(interest) / 100
//        let N = Double(perYear)
//        let T = Double(noOfYears)
        
        var missingValue = 0.0
        if (Initialamount_TF.text?.isEmpty)! {
            missingValue = findMissingInitalAmount(interest: R!, futureValue: A!, noOfYears: T!)
            Initialamount_TF.text = String(missingValue)
        }
        if (Interestrate_TF.text?.isEmpty)! {
            missingValue = findMissingInterestRate(InitalValue: P!, futureValue: A!, noOfYears: T!)
            Interestrate_TF.text = String(missingValue)
        }
        
        if (MonthlyPayments_TF.text?.isEmpty)! {
            missingValue = findMissingMonthly_payments(FutureValue: A!, interest: R!, noOfYears: T!)
            MonthlyPayments_TF.text = String(missingValue)
        }
        if (ProjectedValue_TF.text?.isEmpty)! {
            missingValue = findMissingFuture_value (InitalValue: P!, interest: R!, noOfYears: T!)
            ProjectedValue_TF.text = String(missingValue)
        }
        if (NumberOfPayMents_TF.text?.isEmpty)! {
            missingValue = findMissingNumberOfPayMents(FutureValue: A!, interest: R!, InitalValue: P!)
            NumberOfPayMents_TF.text = String(missingValue)
        }
    }
        /*
        // MARK: - Navigation

        // In a storyboard-based application, you will often want to do a little preparation before navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            // Get the new view controller using segue.destination.
            // Pass the selected object to the new view controller.
        }
        */
        @IBAction func InitalAmount_Change(_ sender: UITextField) {
        if validateTextFields() == 1 {
            /// calculate Missing Component
            calculateMissingComponent()
            
            
        } else if validateTextFields() == 2 {
            showAlert(message: "Invalid Calculation. You must leave one field to proceed with a calculation", title: "Loan Calculation Warning")
        } else {
            showAlert(message: "Please fill at least three fields to perform a calculation", title: "Loan Calculation Warning")
        }
    }
    
    
    @IBAction func InterestRate_Change(_ sender: UITextField) {
        if validateTextFields() == 1 {
            /// calculate Missing Component
            calculateMissingComponent()
            
            
        } else if validateTextFields() == 2 {
            showAlert(message: "Invalid Calculation. You must leave one field to proceed with a calculation", title: "Loan Calculation Warning")
        } else {
            showAlert(message: "Please fill at least three fields to perform a calculation", title: "Loan Calculation Warning")
        }
    }
    
    
    @IBAction func MonthlyPayments_Change(_ sender: UITextField) {
        if validateTextFields() == 1 {
            /// calculate Missing Component
            calculateMissingComponent()
            
            
        } else if validateTextFields() == 1 {
            showAlert(message: "Invalid Calculation. You must leave one field to proceed with a calculation", title: "Loan Calculation Warning")
        } else {
            showAlert(message: "Please fill at least three fields to perform a calculation", title: "Loan Calculation Warning")
        }
    }
    
    
    @IBAction func ProjectedValue_Change(_ sender: UITextField) {
        if validateTextFields() == 1 {
            /// calculate Missing Component
            calculateMissingComponent()
            
            
        } else if validateTextFields() == 2 {
            showAlert(message: "Invalid Calculation. You must leave one field to proceed with a calculation", title: "Loan Calculation Warning")
        } else {
            showAlert(message: "Please fill at least three fields to perform a calculation", title: "Loan Calculation Warning")
        }
    }
    
    
    @IBAction func NumberOfPayments_Change(_ sender: UITextField) {
        if validateTextFields() == 1 {
            /// calculate Missing Component
            calculateMissingComponent()
            
            
        } else if validateTextFields() == 2 {
            showAlert(message: "Invalid Calculation. You must leave one field to proceed with a calculation", title: "Loan Calculation Warning")
        } else {
            showAlert(message: "Please fill at least three fields to perform a calculation", title: "Loan Calculation Warning")
        }
    }

}


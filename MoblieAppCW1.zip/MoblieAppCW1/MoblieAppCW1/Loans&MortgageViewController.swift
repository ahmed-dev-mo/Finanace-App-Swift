//
//  Loans&MortgageViewController.swift
//  MoblieAppCW1
//
//  Created by Ahmed Mohamed on 10/03/2022.


import UIKit
import Foundation

class Loans_MortgageViewController: UIViewController, UITextFieldDelegate {
    
    func showAlert(message: String, title: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBOutlet weak var LoanAmountTF: UITextField!
    @IBOutlet weak var InterestTF: UITextField!
    @IBOutlet weak var NoOfPayTF: UITextField!
    @IBOutlet weak var MonthlypayTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.InterestTF.delegate = self
        
        
        
    }
    
    func validateTexFields() -> Int {
        var counter = 0
        if !(LoanAmountTF.text?.isEmpty)! {
            counter += 1
        }
        if !(InterestTF.text?.isEmpty)! {
            counter += 1
        }
        if !(MonthlypayTF.text?.isEmpty)! {
            counter += 1
        }
        if !(NoOfPayTF.text?.isEmpty)! {
            counter += 1
        }
        
        return counter
    }
    

        
    func resetTextFields() {
        LoanAmountTF.text = ""
        InterestTF.text = ""
        MonthlypayTF.text = ""
        NoOfPayTF.text = ""
    }
    
    //     principalAmount: Double     - P
    //     monthlyPayment: Double    - PMT
    //     terms: Double             - N
    func calculateMissingLoanAmount(interest: Double, monthlyPayment: Double, terms: Double) -> Double {
        let PMT = monthlyPayment
        let R = (interest / 100.0) / 12
        let N = terms
        let P = (PMT / R) * (1 - (1 / pow(1 + R, N)))
        return P.toFixed(2)
        
    }
    
    func calculateMissingLoanMonthlyPayment(interest: Double, principalAmount: Double, terms: Double) -> Double {
        let R = (interest / 100.0) / 12
        let P = principalAmount
        let N = terms
        let PMT = (R * P) / (1 - pow(1 + R, -N))
        return PMT.toFixed(2)
    }
    

    func calculateMissingLoanPaymentTerms(interest: Double, principalAmount: Double, monthlyPayment: Double) throws -> Int {
        /// To find the minimum monthly payment
        let minMonthlyPayment = calculateMissingLoanMonthlyPayment(interest: interest, principalAmount: principalAmount, terms: 1) - principalAmount
        
        if Int(monthlyPayment) <= Int(minMonthlyPayment) {
            throw calculationErr.runtimeError("Invalid monthly payment")
        }
        
        let PMT = monthlyPayment
        let P = principalAmount
        let I = (interest / 100.0) / 12
        let D = PMT / I
        let N = (log(D / (D - P)) / log(1 + I))
        return Int(N)
    }
    
    
    enum calculationErr: Error {
        case runtimeError(String)
    }

    func calculateMissingComponent() {
        ///
        /// A           -    the future value of the investment/loan, including interest
        /// P           -    the principal investment amount (the initial deposit or loan amount – present value)
        /// R           -    the annual interest rate (e.g. 3.2% is 0.032)
        /// N           -    the number of times that interest is compounded per unit time (this is always monthly for the purpose of this coursework, i.e. 12 per year)
        /// T           -     the time the money is invested or borrowed in months
        /// PMT      -    the monthly Payment
        /// PayPY   -    the number of payments per year
        /// CpY       -    the number of compound payments per year
        /// PmtAt    -    the payment due at the beginning or end of each period (default is END)
        ///
        let P = Double(LoanAmountTF.text!)
        let R = Double(InterestTF.text!)
        let PMT = Double(MonthlypayTF.text!)
        let N = Double(NoOfPayTF.text!)
        
        
        /// Identify missing component and Perform relavant calculation
        var missingValue = 0.0
        if (LoanAmountTF.text?.isEmpty)! {
            missingValue = calculateMissingLoanAmount(interest: R!, monthlyPayment: PMT!, terms: N!)
            LoanAmountTF.text = String(missingValue)
        }
        if (MonthlypayTF.text?.isEmpty)! {
            missingValue = calculateMissingLoanMonthlyPayment(interest: R!, principalAmount: P!, terms: N!)
            MonthlypayTF.text = String(missingValue)
        }
        if (NoOfPayTF.text?.isEmpty)! {
            do {
                try missingValue = Double(calculateMissingLoanPaymentTerms(interest: R!, principalAmount: P!, monthlyPayment: PMT!))
            } catch let err {
                print(err)
            }
            NoOfPayTF.text = String(missingValue)
        }
    }
    @IBAction func LoanAmountChange(_ sender: UITextField) {
        if validateTexFields() == 3 {
            /// calculate Missing Component
            calculateMissingComponent()
            
            
        } else if validateTexFields() == 4 {
            showAlert(message: "Invalid Calculation. You must leave one field to proceed with a calculation", title: "Loan Calculation Warning")
        } else {
            showAlert(message: "Please fill at least three fields to perform a calculation", title: "Loan Calculation Warning")
        }
    }
    
    @IBAction func InterestRateChange(_ sender: UITextField) {
        if validateTexFields() == 3 {
            /// calculate Missing Component
            calculateMissingComponent()
            
            
        } else if validateTexFields() == 4 {
            showAlert(message: "Invalid Calculation. You must leave one field to proceed with a calculation", title: "Loan Calculation Warning")
        } else {
            showAlert(message: "Please fill at least three fields to perform a calculation", title: "Loan Calculation Warning")
        }
        
    }
    
    @IBAction func NumberofpaymentsChange(_ sender: UITextField) {
      
    }
    
    @IBAction func MonthlyPaymentsChange(_ sender: UITextField) {
        if validateTexFields() == 3 {
            /// calculate Missing Component
            calculateMissingComponent()
            
            
        } else if validateTexFields() == 4 {
            showAlert(message: "Invalid Calculation. You must leave one field to proceed with a calculation", title: "Loan Calculation Warning")
        } else {
            showAlert(message: "Please fill at least three fields to perform a calculation", title: "Loan Calculation Warning")
        }
        
        
}
    
    
    @IBAction func TapGestureLoans(_ sender: Any) {
        if ((self.view.viewWithTag(1)?.isFirstResponder) != nil)
        {
            LoanAmountTF.resignFirstResponder(); InterestTF.resignFirstResponder(); NoOfPayTF.resignFirstResponder();
            MonthlypayTF.resignFirstResponder();
        }
    }
    
    
}

